import { Prisma } from '@prisma/client'
import { PaginationOrder } from '../pagination/pagination.dto'

interface Pagination<T> {
	cursor?: Pick<T, any>
	cursorField?: Exclude<keyof T, 'AND' | 'OR' | 'NOT'>
	size?: number
	order?: PaginationOrder
	orderBy?: Exclude<keyof T, 'AND' | 'OR' | 'NOT'>
}

export async function paginatePlugin<T>(
	// `this` refers to the current type, e.g. `prisma.modelName` at runtime
	this: T,
	// The `exists` function will use the `where` arguments from the current model, `T`, and the `findFirst` operation
	args: Pagination<Prisma.Args<T, 'findMany'>['where']> &
		Omit<Prisma.Args<T, 'findMany'>, 'take' | 'cursor' | 'orderBy' | 'skip'> = {} as any
) {
	// Retrieve the current model at runtime
	const context = Prisma.getExtensionContext(this) as any
	const { cursorField = 'id' as const, cursor: c, order, orderBy: ob, size, ...options } = args

	const cursor = !!cursorField && !!c ? { [cursorField]: c } : undefined
	const orderBy = !!ob ? { [ob]: order || 'asc' } : undefined
	const skip = cursor ? 1 : undefined

	const data = (await context.findMany({ ...options, take: size, cursor, orderBy, skip })) as Omit<
		Prisma.Args<T, 'findMany'>['where'],
		'AND' | 'OR' | 'NOT'
	>[]

	const nextCursor =
		data.length > 0 && data.length === size
			? (data[data.length - 1][cursorField as any] as Pick<Prisma.Args<T, 'findMany'>['where'], typeof cursorField>)
			: null

	return { data, nextCursor }
}
